
import { Association, User, UserRole, PaymentStatus, Announcement, Idea, IdeaStatus, RegistrationStatus } from './types';

export const ASSOCIATIONS: Association[] = [
  { 
    id: 'foundation-assoc', 
    name: 'Associação em Fundação', 
    brandColor: '#10b981', 
    minSupportsForDirectorReview: 3,
    pixKey: 'pendente',
    monthlyValue: 0,
    annualValue: 0,
    statute: 'Estatuto Inicial em elaboração pelo Fundador Técnico.',
    statuteUpdatedAt: '01/01/2024',
    statuteHistory: [],
    isFoundationMode: true
  }
];

export const MOCK_USER: User = {
  id: 'user-founder',
  name: 'Desenvolvedor Master',
  email: 'dev@plataforma.com',
  role: UserRole.FOUNDER,
  associationId: 'foundation-assoc',
  status: PaymentStatus.ACTIVE,
  registrationStatus: RegistrationStatus.APPROVED,
  startDate: '01/01/2024',
  limitDate: '31/12/2024',
  dueDate: '01/01/2025',
  contributionType: 'ANUAL'
};

export const MOCK_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    associationId: 'foundation-assoc',
    title: 'Modo Fundação Ativo',
    content: 'O sistema está em modo de configuração técnica. Aguardando cadastro da Mesa Diretora para transferência de controle institucional.',
    date: '01/01/2024',
    author: 'Fundador Técnico'
  }
];

export const MOCK_IDEAS: Idea[] = [];
