
import React, { useState, useEffect } from 'react';
import { User, Association, UserRole, PaymentStatus, RegistrationStatus, Idea, Announcement, IdeaStatus } from './types';
import { ASSOCIATIONS, MOCK_USER, MOCK_ANNOUNCEMENTS, MOCK_IDEAS } from './constants';
import Layout from './components/Layout';

const App: React.FC = () => {
  // Estados de visualização e autenticação
  const [view, setView] = useState<'LOGIN' | 'SIGNUP' | 'APP' | 'FOUNDER_ZONE'>('LOGIN');
  const [user, setUser] = useState<User | null>(null);
  const [association, setAssociation] = useState<Association | null>(ASSOCIATIONS[0]);
  const [tab, setTab] = useState('inicio');
  const [editingStatute, setEditingStatute] = useState(ASSOCIATIONS[0].statute);
  const [installPrompt, setInstallPrompt] = useState<any>(null);

  // Estados de Governança e Bootstrap Master
  const [pendingRequests, setPendingRequests] = useState<User[]>([]);
  const [institutionName, setInstitutionName] = useState(ASSOCIATIONS[0].name);
  const [hasFounder, setHasFounder] = useState<boolean>(() => {
    return localStorage.getItem('master_founder_exists') === 'true';
  });

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setInstallPrompt(e);
    });
  }, []);

  const handleInstall = () => {
    if (installPrompt) {
      installPrompt.prompt();
      installPrompt.userChoice.then(() => setInstallPrompt(null));
    }
  };

  // Fluxo de Bootstrap do Primeiro Fundador
  const handleCreateMasterFounder = () => {
    localStorage.setItem('master_founder_exists', 'true');
    setHasFounder(true);
    loginAs(UserRole.FOUNDER);
  };

  const handleSignup = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      role: UserRole.MEMBER,
      associationId: association?.id || 'assoc-1',
      status: PaymentStatus.PENDING,
      registrationStatus: RegistrationStatus.AWAITING_APPROVAL,
      startDate: new Date().toLocaleDateString(),
      limitDate: '',
      dueDate: '',
      contributionType: 'MENSAL'
    };
    setPendingRequests(prev => [...prev, newUser]);
    setUser(newUser);
    setView('APP');
  };

  const loginAs = (role: UserRole) => {
    const mock = { 
      ...MOCK_USER, 
      role, 
      registrationStatus: RegistrationStatus.APPROVED,
      associationId: association?.id || 'assoc-1'
    };
    
    // Configurações específicas por papel
    if (role === UserRole.FOUNDER) {
      mock.name = "Root Fundador";
      mock.email = "master@root.local";
      // O Fundador ignora qualquer trava de aprovação
      mock.registrationStatus = RegistrationStatus.APPROVED;
    } else if (role === UserRole.ADMIN) {
      mock.name = "Presidente Mesa Diretora";
      mock.email = "diretoria@associacao.org";
    }
    
    setUser(mock);
    setTab('inicio');
    setView('APP');
  };

  const handleApprove = (u: User, role: UserRole) => {
    if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.FOUNDER) return;
    setPendingRequests(prev => prev.filter(r => r.id !== u.id));
    alert(`Usuário ${u.name} aprovado como ${role}. Governança atualizada.`);
  };

  const handleUpdateStatute = () => {
    if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.FOUNDER) return;
    if (association) {
      setAssociation({ 
        ...association, 
        statute: editingStatute, 
        statuteUpdatedAt: new Date().toLocaleDateString() 
      });
      alert("Estatuto institucional atualizado.");
    }
  };

  const handleUpdateInstitutionName = (newName: string) => {
    if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.FOUNDER) return;
    setInstitutionName(newName);
    if (association) {
      setAssociation({ ...association, name: newName });
    }
  };

  const handleRemoveAdmin = (adminName: string) => {
    if (user?.role !== UserRole.FOUNDER) return;
    if (confirm(`Atenção Master: Deseja remover a Mesa Diretora (${adminName})? Isso devolverá o controle total ao Fundador.`)) {
      alert("Controle institucional revogado com sucesso.");
    }
  };

  const isFounder = user?.role === UserRole.FOUNDER;
  const isAdminOrFounder = user?.role === UserRole.ADMIN || isFounder;
  const isOperator = user?.role === UserRole.OPERATOR;
  const isTechnicalStaff = isFounder || user?.role === UserRole.SUPPORT;

  // LOGIN SCREEN
  if (view === 'LOGIN' || view === 'FOUNDER_ZONE') {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-6 selection:bg-emerald-500/30">
        <div className="w-full max-w-sm space-y-8 text-center">
          <div className="animate-in fade-in zoom-in duration-700">
            <div className="w-20 h-20 bg-emerald-500 rounded-3xl mx-auto mb-6 flex items-center justify-center text-4xl shadow-2xl shadow-emerald-500/40">🤝</div>
            <h1 className="text-3xl font-bold text-white tracking-tight">AssociaMais</h1>
            <p className="text-slate-400 mt-2">Plataforma de Governança Digital</p>
          </div>

          {view === 'LOGIN' ? (
            <div className="space-y-4 animate-in slide-in-from-bottom-8 duration-500">
              <div className="grid grid-cols-1 gap-3">
                <button onClick={() => loginAs(UserRole.ADMIN)} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold active:scale-[0.98] transition-all shadow-lg shadow-emerald-500/10">Acesso Mesa Diretora</button>
                <button onClick={() => loginAs(UserRole.MEMBER)} className="w-full py-4 bg-white text-slate-900 rounded-2xl font-bold border border-slate-200 active:scale-[0.98] transition-all">Acesso Associado</button>
              </div>
              
              <div className="pt-6 border-t border-slate-800 space-y-4">
                <button onClick={() => setView('SIGNUP')} className="text-emerald-400 text-sm font-bold block w-full">Solicitar Cadastro</button>
                {/* Botão Acesso Fundador Requisitado */}
                <button 
                  onClick={() => setView('FOUNDER_ZONE')} 
                  className="w-full py-4 bg-slate-800 text-amber-500 rounded-2xl font-black uppercase tracking-widest text-xs border border-amber-500/20 active:scale-[0.98] transition-all hover:bg-slate-700"
                >
                  Acesso Fundador
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-6 animate-in fade-in duration-500">
              <div className="bg-amber-500/10 border border-amber-500/20 p-6 rounded-3xl space-y-4">
                <h2 className="text-amber-500 font-black uppercase tracking-widest text-sm">Console Master Root</h2>
                {!hasFounder ? (
                  <div className="space-y-4">
                    <p className="text-xs text-slate-400 leading-relaxed">Nenhum superusuário fundador detectado no sistema. Ative a fundação para assumir o controle total.</p>
                    <button onClick={handleCreateMasterFounder} className="w-full py-4 bg-amber-500 text-white rounded-2xl font-black uppercase tracking-wider">Criar Primeiro Fundador</button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <p className="text-xs text-slate-400">Sistema fundado. Realize o login master para auditoria e manutenção técnica.</p>
                    <button onClick={() => loginAs(UserRole.FOUNDER)} className="w-full py-4 bg-amber-500 text-white rounded-2xl font-black uppercase tracking-wider">Logar como Fundador</button>
                  </div>
                )}
                <button onClick={() => setView('LOGIN')} className="text-slate-500 text-[10px] font-bold uppercase">Voltar ao Início</button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // SIGNUP VIEW
  if (view === 'SIGNUP') {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-6">
          <h2 className="text-2xl font-bold text-white text-center">Cadastro de Associado</h2>
          <form onSubmit={handleSignup} className="space-y-4 animate-in fade-in duration-500">
            <input required name="name" type="text" placeholder="Nome Completo" className="w-full p-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-emerald-500" />
            <input required name="email" type="email" placeholder="E-mail" className="w-full p-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-emerald-500" />
            <input required name="password" type="password" placeholder="Senha" className="w-full p-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-emerald-500" />
            <button type="submit" className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold">Solicitar Acesso</button>
            <button type="button" onClick={() => setView('LOGIN')} className="w-full text-slate-500 text-xs text-center font-bold uppercase">Cancelar</button>
          </form>
        </div>
      </div>
    );
  }

  if (!user || !association) return null;

  // VERIFICAÇÃO DE APROVAÇÃO (Bypass para Fundador)
  if (user.registrationStatus === RegistrationStatus.AWAITING_APPROVAL && !isFounder) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-8 text-center">
        <div className="max-w-xs space-y-6">
          <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center text-4xl mx-auto shadow-sm">⏳</div>
          <h2 className="text-2xl font-bold text-slate-900">Aguardando Mesa Diretora</h2>
          <p className="text-sm text-slate-500">Sua solicitação está em análise. O acesso será liberado pela Mesa Diretora da associação.</p>
          <button onClick={() => {setUser(null); setView('LOGIN');}} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold">Voltar</button>
        </div>
      </div>
    );
  }

  return (
    <Layout user={user} association={association} currentTab={tab} setTab={setTab}>
      <div className="space-y-6 animate-in fade-in duration-300">
        
        {/* INICIO */}
        {tab === 'inicio' && (
          <div className="space-y-6">
            <div className={`p-6 rounded-[32px] text-white shadow-2xl relative overflow-hidden ${isFounder ? 'bg-slate-950 border border-amber-500/30' : 'bg-slate-800'}`}>
              <div className="relative z-10">
                <h2 className="text-xl font-bold">{isFounder ? 'Fundador Root' : 'Olá, ' + user.name.split(' ')[0]}</h2>
                <p className="text-[10px] opacity-60 uppercase font-black tracking-widest mt-1">Status: {user.role}</p>
                
                {isAdminOrFounder && (
                  <div className="mt-4 pt-4 border-t border-white/10 space-y-2">
                    <label className="text-[9px] uppercase font-black text-white/40">Nome da Associação</label>
                    <input 
                      type="text" 
                      className="w-full bg-white/10 border border-white/20 rounded-xl p-2.5 text-xs outline-none focus:ring-2 focus:ring-emerald-500/50"
                      value={institutionName}
                      onChange={(e) => handleUpdateInstitutionName(e.target.value)}
                    />
                  </div>
                )}
              </div>
            </div>

            <section className="space-y-4">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2 px-1">
                <span className="w-1 h-4 bg-emerald-500 rounded-full"></span> Mural Institucional
              </h3>
              {MOCK_ANNOUNCEMENTS.map(ann => (
                <div key={ann.id} className="p-4 bg-white border border-slate-100 rounded-3xl shadow-sm">
                  <h4 className="font-bold text-sm text-slate-900">{ann.title}</h4>
                  <p className="text-xs text-slate-500 mt-1">{ann.content}</p>
                </div>
              ))}
            </section>
          </div>
        )}

        {/* GESTÃO */}
        {tab === 'usuarios' && (isAdminOrFounder || isOperator) && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold px-1 tracking-tight">Gestão Governamental</h2>
            
            {isFounder && (
              <div className="p-5 bg-slate-900 rounded-[32px] text-white space-y-4 border-2 border-amber-500/20">
                <div className="flex items-center gap-2 text-amber-500 text-[10px] font-black uppercase tracking-widest">
                  <span className="w-2.5 h-2.5 bg-amber-500 rounded-full animate-pulse shadow-lg shadow-amber-500/50"></span>
                  Founder Superuser Mode
                </div>
                <div className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-3">
                  <p className="text-[10px] text-slate-400">Você possui controle total sobre a Mesa Diretora. Pode revogar acessos ou transferir o controle institucional.</p>
                  <button 
                    onClick={() => handleRemoveAdmin("Mesa 2024")}
                    className="w-full py-3 bg-red-600/20 text-red-400 rounded-xl text-[10px] font-bold uppercase border border-red-600/30 active:scale-95 transition-all"
                  >
                    Remover Mesa Diretora
                  </button>
                </div>
              </div>
            )}

            <div className="space-y-4">
              <p className="text-[10px] font-black text-slate-400 uppercase px-1">Cadastros Pendentes</p>
              {pendingRequests.length === 0 ? (
                <p className="text-center text-slate-400 py-10 text-xs">Sem solicitações no momento.</p>
              ) : (
                pendingRequests.map(req => (
                  <div key={req.id} className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-sm">
                    <h4 className="font-bold text-slate-900">{req.name}</h4>
                    <p className="text-xs text-slate-500 mb-5">{req.email}</p>
                    <div className="grid grid-cols-2 gap-3">
                      <button onClick={() => handleApprove(req, UserRole.MEMBER)} className="py-3.5 bg-emerald-600 text-white rounded-2xl text-[10px] font-black uppercase active:scale-95">Aprovar</button>
                      <button onClick={() => handleApprove(req, UserRole.ADMIN)} className="py-3.5 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase active:scale-95">Tornar Admin</button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* ESTATUTO */}
        {tab === 'estatuto' && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold px-1">Regimento Interno</h2>
            <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-6">
              {isAdminOrFounder ? (
                <div className="space-y-4">
                  <textarea 
                    className="w-full h-72 p-5 text-sm bg-slate-50 border-2 border-slate-100 rounded-[24px] outline-none focus:border-emerald-500 transition-colors resize-none font-medium text-slate-700 leading-relaxed"
                    value={editingStatute}
                    onChange={(e) => setEditingStatute(e.target.value)}
                  />
                  <button onClick={handleUpdateStatute} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-widest active:scale-95 transition-all">Salvar Alterações</button>
                </div>
              ) : (
                <div className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap font-medium">{association.statute}</div>
              )}
            </div>
          </div>
        )}

        {/* FINANCEIRO */}
        {tab === 'pagamento' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold px-1">Gestão Financeira</h2>
            {isTechnicalStaff ? (
              <div className="p-10 text-center bg-white rounded-[40px] border border-slate-100 space-y-6 shadow-sm">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-4xl grayscale opacity-30 shadow-inner">🔐</div>
                <h3 className="text-lg font-black text-slate-900 uppercase">Acesso Bloqueado</h3>
                <p className="text-[11px] text-slate-500 leading-relaxed px-4 font-medium italic">
                  O Fundador Master e a equipe de suporte técnico não possuem autorização para visualizar dados financeiros privados da associação, garantindo a privacidade bancária dos membros.
                </p>
                <div className="pt-4 border-t border-slate-50">
                   <span className="text-[8px] font-black text-slate-300 uppercase tracking-widest italic">Auditoria Root: Privada</span>
                </div>
              </div>
            ) : (
              <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-6">
                <div className="flex justify-between items-center border-b border-slate-50 pb-5">
                  <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Sua Situação</span>
                  <span className="text-sm font-black text-emerald-600 uppercase bg-emerald-50 px-3 py-1 rounded-full">{user.status}</span>
                </div>
                <div className="p-6 bg-emerald-50 rounded-[24px] border border-emerald-100">
                   <p className="text-[10px] text-emerald-800 font-black uppercase tracking-widest mb-1">Cota Mensal:</p>
                   <p className="text-2xl font-black text-emerald-950">R$ {association.monthlyValue.toFixed(2)}</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* PERFIL */}
        {tab === 'cadastro' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold px-1 tracking-tight">Seu Perfil</h2>
            <div className="bg-white p-8 rounded-[40px] border border-slate-100 space-y-8 shadow-sm relative overflow-hidden">
               <div className="flex flex-col items-center text-center space-y-5">
                  <div className={`w-24 h-24 rounded-[35%] flex items-center justify-center text-4xl font-black border-4 border-white shadow-xl relative ${isFounder ? 'bg-amber-100 text-amber-700 border-amber-500/20' : 'bg-emerald-100 text-emerald-700'}`}>
                    {user.name.charAt(0)}
                    {isFounder && <span className="absolute -top-1 -right-1 text-base bg-amber-400 p-1 rounded-full shadow-lg border-2 border-white">👑</span>}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-xl tracking-tight">{user.name}</h4>
                    <p className="text-sm text-slate-500 font-medium">{user.email}</p>
                  </div>
                </div>
                <div className="pt-6 border-t border-slate-50 space-y-4">
                  <div className="flex justify-between items-center text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <span>Função Global</span>
                    <span className={`px-2 py-0.5 rounded ${isFounder ? 'bg-amber-100 text-amber-700' : 'text-slate-900'}`}>{user.role}</span>
                  </div>
                </div>
            </div>
            
            <button 
              onClick={() => {setUser(null); setView('LOGIN');}} 
              className="w-full py-4 bg-red-50 text-red-600 rounded-2xl text-xs font-black uppercase tracking-widest border border-red-100 active:scale-95 transition-all"
            >
              Logout Seguro
            </button>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default App;
