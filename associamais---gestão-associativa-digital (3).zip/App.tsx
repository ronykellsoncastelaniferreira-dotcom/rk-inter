
import React, { useState, useEffect } from 'react';
import { User, Association, UserRole, PaymentStatus, RegistrationStatus, Idea, Announcement, IdeaStatus } from './types';
import { ASSOCIATIONS, MOCK_USER, MOCK_ANNOUNCEMENTS, MOCK_IDEAS } from './constants';
import Layout from './components/Layout';

const App: React.FC = () => {
  const [view, setView] = useState<'LOGIN' | 'SIGNUP' | 'APP'>('LOGIN');
  const [user, setUser] = useState<User | null>(null);
  const [association, setAssociation] = useState<Association | null>(ASSOCIATIONS[0]);
  const [tab, setTab] = useState('inicio');
  const [editingStatute, setEditingStatute] = useState(ASSOCIATIONS[0].statute);
  const [installPrompt, setInstallPrompt] = useState<any>(null);

  // Estados de Governança
  const [pendingRequests, setPendingRequests] = useState<User[]>([]);
  const [institutionName, setInstitutionName] = useState(ASSOCIATIONS[0].name);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setInstallPrompt(e);
    });
  }, []);

  const handleInstall = () => {
    if (installPrompt) {
      installPrompt.prompt();
      installPrompt.userChoice.then(() => setInstallPrompt(null));
    }
  };

  const handleSignup = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      role: UserRole.MEMBER,
      associationId: association?.id || 'assoc-1',
      status: PaymentStatus.PENDING,
      registrationStatus: RegistrationStatus.AWAITING_APPROVAL,
      startDate: new Date().toLocaleDateString(),
      limitDate: '',
      dueDate: '',
      contributionType: 'MENSAL'
    };
    setPendingRequests(prev => [...prev, newUser]);
    setUser(newUser);
    setView('APP');
  };

  const loginAs = (role: UserRole) => {
    const mock = { 
      ...MOCK_USER, 
      role, 
      registrationStatus: RegistrationStatus.APPROVED,
      associationId: association?.id || 'assoc-1'
    };
    
    // Simulação de nomes para validação de RBAC
    if (role === UserRole.FOUNDER) {
      mock.name = "Desenvolvedor Founder";
      mock.email = "founder@associamais.com";
    } else if (role === UserRole.ADMIN) {
      mock.name = "Presidente Mesa Diretora";
      mock.email = "diretoria@associacao.org";
    } else if (role === UserRole.OPERATOR) {
      mock.name = "Operador Administrativo";
      mock.email = "operador@associacao.org";
    }
    
    setUser(mock);
    setTab('inicio');
    setView('APP');
  };

  const handleApprove = (u: User, role: UserRole) => {
    if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.FOUNDER) return;
    setPendingRequests(prev => prev.filter(r => r.id !== u.id));
    alert(`Usuário ${u.name} aprovado como ${role}. Log técnico registrado.`);
  };

  const handleUpdateStatute = () => {
    if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.FOUNDER) return;
    if (association) {
      setAssociation({ 
        ...association, 
        statute: editingStatute, 
        statuteUpdatedAt: new Date().toLocaleDateString() 
      });
      alert("Estatuto atualizado no servidor.");
    }
  };

  const handleUpdateInstitutionName = (newName: string) => {
    if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.FOUNDER) return;
    setInstitutionName(newName);
    if (association) {
      setAssociation({ ...association, name: newName });
    }
  };

  // Lógica de Permissões (RBAC)
  const isAdminOrFounder = user?.role === UserRole.ADMIN || user?.role === UserRole.FOUNDER;
  const isOperator = user?.role === UserRole.OPERATOR;
  
  // REGRA: Técnicos (Founder/Support) NÃO acessam dados privados (CPF, Saldo Real, etc)
  const canSeePrivateData = user?.role === UserRole.ADMIN || user?.role === UserRole.MEMBER;
  const isTechnicalStaff = user?.role === UserRole.FOUNDER || user?.role === UserRole.SUPPORT;

  if (view !== 'APP') {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-8 text-center">
          <div className="animate-in fade-in zoom-in duration-700">
            <div className="w-20 h-20 bg-emerald-500 rounded-3xl mx-auto mb-6 flex items-center justify-center text-4xl shadow-2xl">🤝</div>
            <h1 className="text-3xl font-bold text-white tracking-tight">AssociaMais</h1>
            <p className="text-slate-400 mt-2">Bem-vindo à {institutionName}</p>
          </div>

          {view === 'LOGIN' ? (
            <div className="space-y-3 animate-in slide-in-from-bottom-8 duration-500">
              <button onClick={() => loginAs(UserRole.FOUNDER)} className="w-full py-4 bg-amber-600 text-white rounded-2xl font-bold active:scale-[0.98] transition-all">Acesso founder_admin</button>
              <button onClick={() => loginAs(UserRole.ADMIN)} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold active:scale-[0.98] transition-all">Acesso admin_associacao</button>
              <button onClick={() => loginAs(UserRole.OPERATOR)} className="w-full py-4 bg-slate-100 text-slate-900 rounded-2xl font-bold active:scale-[0.98] transition-all">Acesso operador</button>
              <button onClick={() => loginAs(UserRole.MEMBER)} className="w-full py-4 bg-white text-slate-900 rounded-2xl font-bold border border-slate-200 active:scale-[0.98] transition-all">Acesso membro</button>
              <div className="pt-4">
                <button onClick={() => setView('SIGNUP')} className="text-emerald-400 text-sm font-bold underline">Cadastre-se para aprovação</button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSignup} className="space-y-4 text-left animate-in fade-in duration-500">
              <input required name="name" type="text" placeholder="Nome Completo" className="w-full p-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-emerald-500" />
              <input required name="email" type="email" placeholder="E-mail" className="w-full p-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-emerald-500" />
              <input required name="password" type="password" placeholder="Senha" className="w-full p-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-emerald-500" />
              <button type="submit" className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold">Solicitar Cadastro</button>
              <button type="button" onClick={() => setView('LOGIN')} className="w-full text-slate-500 text-xs mt-2 text-center">Voltar ao Login</button>
            </form>
          )}
        </div>
      </div>
    );
  }

  if (!user || !association) return null;

  if (user.registrationStatus === RegistrationStatus.AWAITING_APPROVAL) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-8 text-center">
        <div className="max-w-xs space-y-6">
          <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center text-4xl mx-auto shadow-sm">⏳</div>
          <h2 className="text-2xl font-bold text-slate-900">Cadastro Sob Análise</h2>
          <p className="text-sm text-slate-500">O <strong>admin_associacao</strong> está validando seus dados. Você terá acesso pleno em breve.</p>
          <button onClick={() => {setUser(null); setView('LOGIN');}} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold">Sair</button>
        </div>
      </div>
    );
  }

  return (
    <Layout user={user} association={association} currentTab={tab} setTab={setTab}>
      <div className="space-y-6 animate-in fade-in duration-500">
        
        {tab === 'inicio' && (
          <div className="space-y-6">
            <div className="bg-slate-800 p-6 rounded-3xl text-white shadow-xl">
              <h2 className="text-xl font-bold">Olá, {isTechnicalStaff ? 'Suporte Técnico' : user.name.split(' ')[0]}</h2>
              <p className="text-[10px] opacity-60 uppercase font-black tracking-widest mt-1">Sessão: {user.role}</p>
              
              {/* Edição do Nome da Associação para Admins/Founder */}
              {isAdminOrFounder && (
                <div className="mt-4 pt-4 border-t border-white/10 space-y-2">
                  <label className="text-[9px] uppercase font-bold text-white/40">Nome da Associação (Dinâmico)</label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      className="flex-1 bg-white/10 border border-white/20 rounded-lg p-2 text-xs outline-none focus:border-emerald-500"
                      value={institutionName}
                      onChange={(e) => handleUpdateInstitutionName(e.target.value)}
                    />
                  </div>
                </div>
              )}
            </div>

            <section className="space-y-4">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2 px-1">
                <span className="w-1 h-4 bg-emerald-500 rounded-full"></span> Mural de Avisos
              </h3>
              {MOCK_ANNOUNCEMENTS.map(ann => (
                <div key={ann.id} className="p-4 bg-white border border-slate-100 rounded-2xl shadow-sm">
                  <h4 className="font-bold text-sm text-slate-900">{ann.title}</h4>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">{ann.content}</p>
                </div>
              ))}
            </section>
          </div>
        )}

        {tab === 'usuarios' && (isAdminOrFounder || isOperator) && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold px-1">Gestão de Governança</h2>
            
            {/* CONSOLE TÉCNICO EXCLUSIVO FOUNDER */}
            {user.role === UserRole.FOUNDER && (
              <div className="p-4 bg-slate-900 rounded-2xl border-2 border-emerald-500/20">
                <p className="text-[9px] text-emerald-400 font-bold uppercase mb-2">founder_admin_console</p>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 bg-slate-800 rounded text-[10px] text-slate-300">RBAC Status: Active</div>
                  <div className="p-2 bg-slate-800 rounded text-[10px] text-slate-300">Auditoria: 100%</div>
                </div>
              </div>
            )}

            {pendingRequests.length === 0 ? (
              <p className="text-center text-slate-400 py-10 text-sm">Nenhum cadastro aguardando.</p>
            ) : (
              <div className="space-y-4">
                {pendingRequests.map(req => (
                  <div key={req.id} className="bg-white border border-slate-100 p-5 rounded-3xl shadow-sm">
                    <h4 className="font-bold text-slate-900">{req.name}</h4>
                    <p className="text-xs text-slate-500 mb-4">{req.email}</p>
                    <div className="flex gap-2">
                      <button onClick={() => handleApprove(req, UserRole.MEMBER)} className="flex-1 py-3 bg-emerald-600 text-white rounded-xl text-[10px] font-bold uppercase">Membro</button>
                      <button onClick={() => handleApprove(req, UserRole.OPERATOR)} className="flex-1 py-3 bg-slate-800 text-white rounded-xl text-[10px] font-bold uppercase">Operador</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'estatuto' && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold px-1">Regimento e Normas</h2>
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
              {isAdminOrFounder ? (
                <div className="space-y-4">
                  <textarea 
                    className="w-full h-64 p-4 text-sm bg-slate-50 border-2 border-slate-100 rounded-3xl outline-none focus:border-emerald-500 transition-colors resize-none"
                    value={editingStatute}
                    onChange={(e) => setEditingStatute(e.target.value)}
                  />
                  <button onClick={handleUpdateStatute} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-500/10">Atualizar Estatuto</button>
                </div>
              ) : (
                <div className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap">{association.statute}</div>
              )}
            </div>
          </div>
        )}

        {tab === 'pagamento' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold px-1">Portal Financeiro</h2>
            {isTechnicalStaff ? (
              <div className="p-10 text-center bg-white rounded-[40px] border-2 border-dashed border-slate-200 space-y-4">
                <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-4xl grayscale opacity-30">🔐</div>
                <h3 className="text-lg font-bold text-slate-900 font-mono">DATA_ISOLATION_ACTIVE</h3>
                <p className="text-[11px] text-slate-500 leading-relaxed px-4">
                  O <strong>founder_admin</strong> possui acesso técnico total aos módulos de código, mas está bloqueado de visualizar o fluxo de caixa real por razões de governança institucional.
                </p>
              </div>
            ) : (
              <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-5">
                <div className="flex justify-between items-center border-b pb-5">
                  <span className="text-xs font-bold text-slate-400 uppercase">Sua Cota</span>
                  <span className="text-sm font-black text-emerald-600 uppercase italic">{user.status}</span>
                </div>
                <div className="p-5 bg-emerald-50 border border-emerald-100 rounded-3xl">
                   <p className="text-[10px] text-emerald-800 font-black uppercase mb-2">Vencimento em {user.dueDate || '15/06/2024'}</p>
                   <p className="text-lg font-black text-emerald-950">R$ {association.monthlyValue.toFixed(2)}</p>
                </div>
              </div>
            )}
          </div>
        )}

        {tab === 'cadastro' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold px-1">Dados Cadastrais</h2>
            <div className="bg-white p-6 rounded-[40px] border border-slate-100 space-y-8 shadow-sm relative overflow-hidden">
               {isTechnicalStaff ? (
                 <div className="space-y-4">
                   <div className="flex items-center gap-4">
                     <div className="w-16 h-16 bg-slate-100 rounded-2xl animate-pulse"></div>
                     <div className="flex-1 space-y-2">
                       <div className="h-4 bg-slate-100 rounded animate-pulse"></div>
                       <div className="h-3 bg-slate-100 rounded animate-pulse w-2/3"></div>
                     </div>
                   </div>
                   <p className="text-[10px] text-slate-400 font-bold uppercase text-center pt-4">🔒 Dados sensíveis ocultados para suporte técnico</p>
                 </div>
               ) : (
                <>
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="w-20 h-20 bg-emerald-100 text-emerald-700 rounded-3xl flex items-center justify-center text-3xl font-black border-4 border-white shadow-xl">
                      {user.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-lg">{user.name}</h4>
                      <p className="text-sm text-slate-500">{user.email}</p>
                    </div>
                  </div>
                  <div className="pt-6 border-t border-slate-50 space-y-4">
                    <div className="flex justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                      <span>Nível de Acesso</span>
                      <span className="text-slate-900 font-black">{user.role}</span>
                    </div>
                  </div>
                </>
               )}
            </div>
            
            <button 
              onClick={() => {setUser(null); setView('LOGIN');}} 
              className="w-full py-4 bg-red-50 text-red-600 rounded-2xl text-xs font-bold border border-red-100"
            >
              Logoff Seguro
            </button>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default App;
