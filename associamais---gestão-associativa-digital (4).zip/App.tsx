
import React, { useState, useEffect } from 'react';
import { User, Association, UserRole, PaymentStatus, RegistrationStatus, Idea, Announcement, IdeaStatus } from './types';
import { ASSOCIATIONS, MOCK_USER, MOCK_ANNOUNCEMENTS, MOCK_IDEAS } from './constants';
import Layout from './components/Layout';

const App: React.FC = () => {
  const [view, setView] = useState<'LOGIN' | 'SIGNUP' | 'APP'>('LOGIN');
  const [user, setUser] = useState<User | null>(null);
  const [association, setAssociation] = useState<Association | null>(ASSOCIATIONS[0]);
  const [tab, setTab] = useState('inicio');
  const [editingStatute, setEditingStatute] = useState(ASSOCIATIONS[0].statute);
  const [installPrompt, setInstallPrompt] = useState<any>(null);

  // Estados de Governança e Bootstrap
  const [pendingRequests, setPendingRequests] = useState<User[]>([]);
  const [institutionName, setInstitutionName] = useState(ASSOCIATIONS[0].name);
  const [hasFounder, setHasFounder] = useState<boolean>(() => {
    return localStorage.getItem('founder_bootstrapped') === 'true';
  });

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setInstallPrompt(e);
    });
  }, []);

  const handleInstall = () => {
    if (installPrompt) {
      installPrompt.prompt();
      installPrompt.userChoice.then(() => setInstallPrompt(null));
    }
  };

  const handleBootstrapFounder = () => {
    localStorage.setItem('founder_bootstrapped', 'true');
    setHasFounder(true);
    loginAs(UserRole.FOUNDER);
  };

  const handleSignup = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      role: UserRole.MEMBER,
      associationId: association?.id || 'assoc-1',
      status: PaymentStatus.PENDING,
      registrationStatus: RegistrationStatus.AWAITING_APPROVAL,
      startDate: new Date().toLocaleDateString(),
      limitDate: '',
      dueDate: '',
      contributionType: 'MENSAL'
    };
    setPendingRequests(prev => [...prev, newUser]);
    setUser(newUser);
    setView('APP');
  };

  const loginAs = (role: UserRole) => {
    const mock = { 
      ...MOCK_USER, 
      role, 
      registrationStatus: RegistrationStatus.APPROVED,
      associationId: association?.id || 'assoc-1'
    };
    
    if (role === UserRole.FOUNDER) {
      mock.name = "Fundador do Sistema";
      mock.email = "founder@associamais.com";
    } else if (role === UserRole.ADMIN) {
      mock.name = "Presidente Mesa Diretora";
      mock.email = "diretoria@associacao.org";
    } else if (role === UserRole.OPERATOR) {
      mock.name = "Operador Administrativo";
      mock.email = "operador@associacao.org";
    }
    
    setUser(mock);
    setTab('inicio');
    setView('APP');
  };

  const handleApprove = (u: User, role: UserRole) => {
    // Apenas ADMIN ou FOUNDER podem aprovar
    if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.FOUNDER) return;
    setPendingRequests(prev => prev.filter(r => r.id !== u.id));
    alert(`Usuário ${u.name} aprovado como ${role}.`);
  };

  const handleUpdateStatute = () => {
    if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.FOUNDER) return;
    if (association) {
      setAssociation({ 
        ...association, 
        statute: editingStatute, 
        statuteUpdatedAt: new Date().toLocaleDateString() 
      });
      alert("Estatuto atualizado com sucesso.");
    }
  };

  const handleUpdateInstitutionName = (newName: string) => {
    if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.FOUNDER) return;
    setInstitutionName(newName);
    if (association) {
      setAssociation({ ...association, name: newName });
    }
  };

  const handleTransferToMesa = () => {
    if (user?.role !== UserRole.FOUNDER) return;
    if (confirm("Você deseja transferir o controle total para a Mesa Diretora? Seu papel permanecerá como Fundador Técnico, mas a gestão institucional passará aos eleitos.")) {
      if (association) {
        setAssociation({ ...association, isFoundationMode: false });
      }
      alert("Controle institucional transferido com sucesso.");
    }
  };

  // RBAC Lógica
  const isFounder = user?.role === UserRole.FOUNDER;
  const isAdminOrFounder = user?.role === UserRole.ADMIN || isFounder;
  const isOperator = user?.role === UserRole.OPERATOR;
  
  // Técnicos/Fundadores vêem a interface técnica mas respeitam a privacidade de dados sensíveis dos membros (LGPD)
  const canSeePrivateData = user?.role === UserRole.ADMIN || user?.role === UserRole.MEMBER;
  const isTechnicalStaff = isFounder || user?.role === UserRole.SUPPORT;

  if (view !== 'APP') {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-8 text-center">
          <div className="animate-in fade-in zoom-in duration-700">
            <div className="w-20 h-20 bg-emerald-500 rounded-3xl mx-auto mb-6 flex items-center justify-center text-4xl shadow-2xl shadow-emerald-500/40">🤝</div>
            <h1 className="text-3xl font-bold text-white tracking-tight">AssociaMais</h1>
            <p className="text-slate-400 mt-2">Bem-vindo à {institutionName}</p>
          </div>

          {view === 'LOGIN' ? (
            <div className="space-y-3 animate-in slide-in-from-bottom-8 duration-500">
              {!hasFounder ? (
                <button onClick={handleBootstrapFounder} className="w-full py-4 bg-amber-500 text-white rounded-2xl font-black uppercase tracking-widest active:scale-[0.98] transition-all shadow-lg shadow-amber-500/20">
                  ⚠️ Ativar Modo Fundação
                </button>
              ) : (
                <button onClick={() => loginAs(UserRole.FOUNDER)} className="w-full py-4 bg-slate-800 text-amber-400 rounded-2xl font-bold border border-slate-700 active:scale-[0.98] transition-all">
                  Acesso Fundador
                </button>
              )}
              
              <button onClick={() => loginAs(UserRole.ADMIN)} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold active:scale-[0.98] transition-all">Mesa Diretora</button>
              <button onClick={() => loginAs(UserRole.OPERATOR)} className="w-full py-4 bg-slate-100 text-slate-900 rounded-2xl font-bold active:scale-[0.98] transition-all">Operador</button>
              <button onClick={() => loginAs(UserRole.MEMBER)} className="w-full py-4 bg-white text-slate-900 rounded-2xl font-bold border border-slate-200 active:scale-[0.98] transition-all">Membro</button>
              
              <div className="pt-4">
                <button onClick={() => setView('SIGNUP')} className="text-emerald-400 text-sm font-bold underline decoration-emerald-500/30 underline-offset-4">Solicitar Cadastro</button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSignup} className="space-y-4 text-left animate-in fade-in duration-500">
              <input required name="name" type="text" placeholder="Nome Completo" className="w-full p-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-emerald-500" />
              <input required name="email" type="email" placeholder="E-mail" className="w-full p-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-emerald-500" />
              <input required name="password" type="password" placeholder="Senha" className="w-full p-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-emerald-500" />
              <button type="submit" className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold">Solicitar Acesso</button>
              <button type="button" onClick={() => setView('LOGIN')} className="w-full text-slate-500 text-xs mt-2 text-center font-medium">Voltar ao Login</button>
            </form>
          )}
        </div>
      </div>
    );
  }

  if (!user || !association) return null;

  if (user.registrationStatus === RegistrationStatus.AWAITING_APPROVAL) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-8 text-center">
        <div className="max-w-xs space-y-6">
          <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center text-4xl mx-auto shadow-sm">⏳</div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Sob Análise</h2>
          <p className="text-sm text-slate-500 leading-relaxed italic">Sua solicitação está sendo validada pela Mesa Diretora de <strong>{institutionName}</strong>.</p>
          <button onClick={() => {setUser(null); setView('LOGIN');}} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold shadow-xl">Entendido</button>
        </div>
      </div>
    );
  }

  return (
    <Layout user={user} association={association} currentTab={tab} setTab={setTab}>
      <div className="space-y-6 animate-in fade-in duration-300">
        
        {tab === 'inicio' && (
          <div className="space-y-6">
            <div className="bg-slate-800 p-6 rounded-[32px] text-white shadow-2xl relative overflow-hidden">
              <div className="relative z-10">
                <h2 className="text-xl font-bold leading-tight">Olá, {isFounder ? 'Fundador Master' : user.name.split(' ')[0]}</h2>
                <p className="text-[10px] opacity-60 uppercase font-black tracking-widest mt-1">Acesso: {user.role}</p>
                
                {isAdminOrFounder && (
                  <div className="mt-4 pt-4 border-t border-white/10 space-y-2">
                    <label className="text-[9px] uppercase font-black text-white/40 tracking-wider">Nome da Associação</label>
                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        className="flex-1 bg-white/10 border border-white/20 rounded-xl p-2.5 text-xs outline-none focus:ring-2 focus:ring-emerald-500/50"
                        value={institutionName}
                        onChange={(e) => handleUpdateInstitutionName(e.target.value)}
                      />
                    </div>
                  </div>
                )}
              </div>
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl"></div>
            </div>

            {isFounder && (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-3xl">
                <h4 className="text-[10px] font-black text-amber-800 uppercase tracking-widest mb-3">Painel de Controle Fundação</h4>
                <div className="space-y-2">
                   <button 
                     onClick={handleTransferToMesa}
                     className="w-full py-3 bg-amber-600 text-white rounded-xl text-xs font-bold uppercase active:scale-[0.98] transition-all"
                   >
                     Transferir Controle p/ Mesa Diretora
                   </button>
                   <p className="text-[9px] text-amber-600 italic px-2">O controle institucional remove o Modo Fundação, oficializando a governança interna.</p>
                </div>
              </div>
            )}

            <section className="space-y-4">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2 px-1">
                <span className="w-1 h-4 bg-emerald-500 rounded-full"></span> Mural Geral
              </h3>
              {MOCK_ANNOUNCEMENTS.map(ann => (
                <div key={ann.id} className="p-4 bg-white border border-slate-100 rounded-3xl shadow-sm">
                  <h4 className="font-bold text-sm text-slate-900">{ann.title}</h4>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">{ann.content}</p>
                </div>
              ))}
            </section>
          </div>
        )}

        {tab === 'usuarios' && (isAdminOrFounder || isOperator) && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold px-1 tracking-tight">Gestão de Membros</h2>
            
            {isFounder && (
              <div className="p-4 bg-slate-950 rounded-[32px] text-white space-y-3 shadow-inner">
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-black uppercase tracking-widest">
                  <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.5)] animate-pulse"></span>
                  Founder Superuser Console
                </div>
                <p className="text-[10px] text-slate-400 font-medium">Acesso root ativo. Auditoria de mesa diretora e usuários liberada.</p>
                <div className="flex gap-2">
                  <span className="text-[9px] bg-white/5 px-2.5 py-1 rounded-full border border-white/10 font-bold">SYSTEM_MASTER_TOKEN: OK</span>
                </div>
              </div>
            )}

            {pendingRequests.length === 0 ? (
              <div className="py-16 text-center space-y-4">
                <div className="text-4xl">✨</div>
                <p className="text-slate-400 text-sm font-medium">Nenhum cadastro aguardando no servidor.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {pendingRequests.map(req => (
                  <div key={req.id} className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-sm active:scale-[0.99] transition-transform">
                    <h4 className="font-bold text-slate-900">{req.name}</h4>
                    <p className="text-xs text-slate-500 mb-5">{req.email}</p>
                    <div className="grid grid-cols-2 gap-3">
                      <button onClick={() => handleApprove(req, UserRole.MEMBER)} className="py-3.5 bg-emerald-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition-all">Associar</button>
                      <button onClick={() => handleApprove(req, UserRole.ADMIN)} className="py-3.5 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition-all">Mesa Dir.</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'estatuto' && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold px-1 tracking-tight">Normas & Estatuto</h2>
            <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-6">
              {isAdminOrFounder ? (
                <div className="space-y-4">
                  <textarea 
                    className="w-full h-72 p-5 text-sm bg-slate-50 border-2 border-slate-100 rounded-[24px] outline-none focus:border-emerald-500 transition-colors resize-none font-medium text-slate-700 leading-relaxed"
                    value={editingStatute}
                    onChange={(e) => setEditingStatute(e.target.value)}
                  />
                  <button onClick={handleUpdateStatute} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-lg shadow-emerald-500/10 active:scale-95 transition-all">Salvar Documento</button>
                </div>
              ) : (
                <div className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap font-medium">{association.statute}</div>
              )}
            </div>
          </div>
        )}

        {tab === 'pagamento' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold px-1 tracking-tight">Financeiro Digital</h2>
            {isTechnicalStaff ? (
              <div className="p-10 text-center bg-white rounded-[40px] border border-slate-100 space-y-6">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-4xl grayscale opacity-30 shadow-inner">🔐</div>
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter">Segurança de Dados</h3>
                <p className="text-[11px] text-slate-500 leading-relaxed px-4 font-medium italic">
                  O Fundador e a equipe técnica possuem acesso ao motor do sistema, mas por proteção de privacidade da associação, o fluxo financeiro é isolado à Mesa Diretora e Membros.
                </p>
                <div className="pt-4 border-t border-slate-50">
                   <span className="text-[8px] font-black text-slate-300 uppercase tracking-widest">Token de Auditoria: Ativo</span>
                </div>
              </div>
            ) : (
              <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-6">
                <div className="flex justify-between items-center border-b border-slate-50 pb-5">
                  <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Sua Mensalidade</span>
                  <span className="text-sm font-black text-emerald-600 uppercase italic px-3 py-1 bg-emerald-50 rounded-full">{user.status}</span>
                </div>
                <div className="p-6 bg-gradient-to-br from-emerald-50 to-emerald-100/50 border border-emerald-100 rounded-[24px] shadow-sm">
                   <p className="text-[10px] text-emerald-800 font-black uppercase tracking-widest mb-2">Vencimento Próximo:</p>
                   <p className="text-2xl font-black text-emerald-950">R$ {association.monthlyValue.toFixed(2)}</p>
                   <p className="text-[10px] text-emerald-700 mt-2 font-bold tracking-tight">Data Base: 15 de cada mês</p>
                </div>
              </div>
            )}
          </div>
        )}

        {tab === 'cadastro' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold px-1 tracking-tight">Perfil Associativo</h2>
            <div className="bg-white p-8 rounded-[40px] border border-slate-100 space-y-8 shadow-sm relative overflow-hidden">
               {isTechnicalStaff && !isFounder ? (
                 <div className="space-y-5 py-6">
                   <div className="w-16 h-16 bg-slate-50 rounded-2xl animate-pulse mx-auto"></div>
                   <div className="h-4 bg-slate-50 rounded animate-pulse w-3/4 mx-auto"></div>
                   <p className="text-[9px] text-slate-400 font-black uppercase text-center tracking-widest">🛡️ Perfil Protegido por RBAC</p>
                 </div>
               ) : (
                <>
                  <div className="flex flex-col items-center text-center space-y-5">
                    <div className="w-24 h-24 bg-gradient-to-tr from-emerald-100 to-emerald-200 text-emerald-700 rounded-[35%] flex items-center justify-center text-4xl font-black border-4 border-white shadow-xl relative">
                      {user.name.charAt(0)}
                      {isFounder && <span className="absolute -bottom-1 -right-1 text-base bg-amber-400 p-1.5 rounded-full shadow-lg border-2 border-white">👑</span>}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-xl tracking-tight">{user.name}</h4>
                      <p className="text-sm text-slate-500 font-medium">{user.email}</p>
                    </div>
                  </div>
                  <div className="pt-6 border-t border-slate-50 space-y-4">
                    <div className="flex justify-between items-center text-[10px] font-black text-slate-400 uppercase tracking-widest">
                      <span>Nível Global</span>
                      <span className={`px-2 py-0.5 rounded ${isFounder ? 'bg-amber-100 text-amber-700' : 'text-slate-900'}`}>{user.role}</span>
                    </div>
                    <div className="flex justify-between items-center text-[10px] font-black text-slate-400 uppercase tracking-widest">
                      <span>Sistema PWA</span>
                      <span className="text-slate-900">Ver. 2.5.0-master</span>
                    </div>
                  </div>
                </>
               )}
            </div>
            
            <button 
              onClick={() => {setUser(null); setView('LOGIN');}} 
              className="w-full py-4 bg-red-50 text-red-600 rounded-2xl text-xs font-black uppercase tracking-widest border border-red-100 active:scale-95 transition-all shadow-sm"
            >
              Logout Institucional
            </button>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default App;
