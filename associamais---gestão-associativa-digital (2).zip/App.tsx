
import React, { useState, useEffect } from 'react';
import { User, Association, UserRole, PaymentStatus, RegistrationStatus, Idea, Announcement, IdeaStatus } from './types';
import { ASSOCIATIONS, MOCK_USER, MOCK_ANNOUNCEMENTS, MOCK_IDEAS } from './constants';
import Layout from './components/Layout';

const App: React.FC = () => {
  const [view, setView] = useState<'LOGIN' | 'SIGNUP' | 'APP'>('LOGIN');
  const [user, setUser] = useState<User | null>(null);
  const [association, setAssociation] = useState<Association | null>(ASSOCIATIONS[0]);
  const [tab, setTab] = useState('inicio');
  const [editingStatute, setEditingStatute] = useState(ASSOCIATIONS[0].statute);
  const [installPrompt, setInstallPrompt] = useState<any>(null);

  // MOCK DB: Gerenciamento de solicitações e usuários
  const [pendingRequests, setPendingRequests] = useState<User[]>([]);
  const [institutionName, setInstitutionName] = useState(ASSOCIATIONS[0].name);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setInstallPrompt(e);
    });
  }, []);

  const handleInstall = () => {
    if (installPrompt) {
      installPrompt.prompt();
      installPrompt.userChoice.then(() => setInstallPrompt(null));
    }
  };

  const handleSignup = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      role: UserRole.MEMBER,
      associationId: association?.id || 'assoc-1',
      status: PaymentStatus.PENDING,
      registrationStatus: RegistrationStatus.AWAITING_APPROVAL,
      startDate: new Date().toLocaleDateString(),
      limitDate: '',
      dueDate: '',
      contributionType: 'MENSAL'
    };
    // Em um app real, isso iria para o backend
    setPendingRequests(prev => [...prev, newUser]);
    setUser(newUser);
    setView('APP');
  };

  const loginAs = (role: UserRole) => {
    const mock = { 
      ...MOCK_USER, 
      role, 
      registrationStatus: RegistrationStatus.APPROVED,
      associationId: association?.id || 'assoc-1'
    };
    
    // Ajuste de nomes para demonstração de papéis
    if (role === UserRole.SUPPORT) {
      mock.name = "Suporte Técnico Autorizado";
      mock.email = "suporte@associamais.com";
    } else if (role === UserRole.ADMIN) {
      mock.name = "Presidente da Mesa";
      mock.email = "presidente@associacao.org";
    } else if (role === UserRole.MEMBER) {
      mock.name = "Associado Regular";
      mock.email = "membro@provedor.com";
    }
    
    setUser(mock);
    setTab('inicio');
    setView('APP');
  };

  const handleApprove = (u: User, role: UserRole) => {
    if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.FOUNDER) return;
    setPendingRequests(prev => prev.filter(r => r.id !== u.id));
    alert(`Usuário ${u.name} aprovado como ${role}. Log de auditoria registrado.`);
  };

  const handleTransferControl = () => {
    if (user?.role !== UserRole.FOUNDER) return;
    if (association) {
      setAssociation({ ...association, isFoundationMode: false });
      alert("CONTROLE TRANSFERIDO: A Mesa Diretora agora detém o poder institucional total. Seu perfil foi alterado para Suporte Técnico.");
      setUser({ ...user, role: UserRole.SUPPORT });
    }
  };

  const handleUpdateStatute = () => {
    if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.FOUNDER) return;
    if (association) {
      setAssociation({ 
        ...association, 
        statute: editingStatute, 
        statuteUpdatedAt: new Date().toLocaleDateString() 
      });
      alert("Estatuto institucional atualizado com sucesso.");
    }
  };

  const handleUpdateInstitutionName = (newName: string) => {
    if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.FOUNDER) return;
    setInstitutionName(newName);
    if (association) {
      setAssociation({ ...association, name: newName });
    }
  };

  // Helper para verificar se o usuário atual pode ver dados sensíveis
  // IF(userRole = "Administrador Técnico" OR "Fundador Técnico", HIDE, SHOW)
  // Fix: Define the missing 'isAdmin' constant based on user role.
  const isAdmin = user?.role === UserRole.ADMIN || user?.role === UserRole.FOUNDER;
  const canSeeSensitiveData = user?.role === UserRole.ADMIN || user?.role === UserRole.MEMBER;
  const isTechnicalStaff = user?.role === UserRole.FOUNDER || user?.role === UserRole.SUPPORT;

  if (view !== 'APP') {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-8 text-center">
          <div className="animate-in fade-in zoom-in duration-700">
            <div className="w-20 h-20 bg-emerald-500 rounded-3xl mx-auto mb-6 flex items-center justify-center text-4xl shadow-2xl">🤝</div>
            <h1 className="text-3xl font-bold text-white tracking-tight">AssociaMais</h1>
            <p className="text-slate-400 mt-2">Bem-vindo à {institutionName}</p>
          </div>

          {view === 'LOGIN' ? (
            <div className="space-y-3 animate-in slide-in-from-bottom-8 duration-500">
              <button onClick={() => loginAs(UserRole.FOUNDER)} className="w-full py-4 bg-amber-600 text-white rounded-2xl font-bold active:scale-[0.98] transition-all">Acesso Fundador Técnico</button>
              <button onClick={() => loginAs(UserRole.ADMIN)} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold active:scale-[0.98] transition-all">Acesso Mesa Diretora</button>
              <button onClick={() => loginAs(UserRole.MEMBER)} className="w-full py-4 bg-white text-slate-900 rounded-2xl font-bold active:scale-[0.98] transition-all">Acesso Associado</button>
              <button onClick={() => loginAs(UserRole.SUPPORT)} className="w-full py-4 bg-slate-800 text-slate-400 rounded-2xl font-bold border border-slate-700 active:scale-[0.98] transition-all">Suporte Técnico</button>
              <div className="pt-4">
                <button onClick={() => setView('SIGNUP')} className="text-emerald-400 text-sm font-bold underline">Não tem conta? Cadastre-se</button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSignup} className="space-y-4 text-left animate-in fade-in duration-500">
              <input required name="name" type="text" placeholder="Nome Completo" className="w-full p-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-emerald-500" />
              <input required name="email" type="email" placeholder="E-mail" className="w-full p-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-emerald-500" />
              <input required name="password" type="password" placeholder="Senha" className="w-full p-4 bg-slate-800 border border-slate-700 rounded-2xl text-white outline-none focus:ring-2 focus:ring-emerald-500" />
              <button type="submit" className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold active:scale-[0.98] transition-all">Solicitar Acesso</button>
              <button type="button" onClick={() => setView('LOGIN')} className="w-full text-slate-500 text-xs mt-2 text-center">Voltar ao Login</button>
            </form>
          )}

          {installPrompt && (
            <button onClick={handleInstall} className="mt-4 text-xs font-bold text-emerald-500 border border-emerald-500/30 px-4 py-2 rounded-full bg-emerald-500/5">
              ✨ Instalar AssociaMais no Dispositivo
            </button>
          )}
        </div>
      </div>
    );
  }

  if (!user || !association) return null;

  if (user.registrationStatus === RegistrationStatus.AWAITING_APPROVAL) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-8 text-center">
        <div className="max-w-xs space-y-6">
          <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center text-4xl mx-auto shadow-sm">⏳</div>
          <h2 className="text-2xl font-bold text-slate-900">Cadastro em Análise</h2>
          <p className="text-sm text-slate-500 italic">Sua solicitação foi enviada para a Mesa Diretora de <strong>{institutionName}</strong>.</p>
          <p className="text-xs text-slate-400">Você receberá acesso total assim que seu perfil for aprovado pelos administradores.</p>
          <button onClick={() => {setUser(null); setView('LOGIN');}} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold">Sair</button>
        </div>
      </div>
    );
  }

  return (
    <Layout user={user} association={association} currentTab={tab} setTab={setTab}>
      <div className="space-y-6 animate-in fade-in duration-500">
        
        {/* TELA DE INÍCIO */}
        {tab === 'inicio' && (
          <div className="space-y-6">
            <div className="bg-slate-800 p-6 rounded-3xl text-white shadow-xl relative overflow-hidden">
              <div className="relative z-10">
                <h2 className="text-xl font-bold leading-tight">Olá, {isTechnicalStaff ? 'Equipe Técnica' : user.name.split(' ')[0]}</h2>
                <p className="text-[10px] opacity-60 uppercase font-black tracking-widest mt-1">{user.role}</p>
                <div className="mt-4 flex items-center gap-2">
                  <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></span>
                  <span className="bg-emerald-500/20 text-emerald-400 px-3 py-1 rounded-lg text-[10px] font-bold border border-emerald-500/20">SISTEMA ATIVO</span>
                </div>
              </div>
              <div className="absolute top-0 right-0 p-4 opacity-10 text-6xl">🏢</div>
            </div>

            {/* MODO FUNDAÇÃO - ALERTA TÉCNICO */}
            {association.isFoundationMode && user.role === UserRole.FOUNDER && (
              <div className="p-5 bg-amber-50 border-2 border-amber-100 rounded-3xl space-y-3">
                <div className="flex items-center gap-2 text-amber-800 font-bold text-sm">
                  <span>⚠️</span> MODO FUNDAÇÃO ATIVO
                </div>
                <p className="text-xs text-amber-700">Como Fundador Técnico, você deve configurar o nome da instituição e o estatuto inicial antes de transferir o controle para a Mesa Diretora.</p>
                <div className="space-y-2">
                   <input 
                     type="text" 
                     placeholder="Nome Institucional" 
                     className="w-full p-3 bg-white border border-amber-200 rounded-xl text-sm"
                     value={institutionName}
                     onChange={(e) => handleUpdateInstitutionName(e.target.value)}
                   />
                   <button 
                     onClick={handleTransferControl}
                     className="w-full py-3 bg-amber-600 text-white rounded-xl text-xs font-bold uppercase"
                   >
                     Confirmar Mesa Diretora & Transferir Controle
                   </button>
                </div>
              </div>
            )}

            <section className="space-y-4">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <span className="w-1 h-4 bg-emerald-500 rounded-full"></span> Mural Institucional
              </h3>
              {MOCK_ANNOUNCEMENTS.map(ann => (
                <div key={ann.id} className="p-4 bg-white border border-slate-100 rounded-2xl shadow-sm">
                  <h4 className="font-bold text-sm text-slate-900">{ann.title}</h4>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">{ann.content}</p>
                  <div className="mt-3 flex justify-between items-center text-[9px] font-bold text-slate-400 uppercase">
                    <span>{ann.author}</span>
                    <span>{ann.date}</span>
                  </div>
                </div>
              ))}
            </section>
          </div>
        )}

        {/* TELA DE GESTÃO (ADMIN/FOUNDER ONLY) */}
        {tab === 'usuarios' && (isAdmin || user.role === UserRole.FOUNDER) && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Controle de Membros</h2>
            
            {/* AREA TECNICA (ISOLADA) */}
            <div className="p-4 bg-slate-900 rounded-3xl text-white space-y-3">
               <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase">
                 <span className="w-2 h-2 bg-emerald-500 rounded-full"></span> Console Estrutural
               </div>
               <p className="text-[10px] text-slate-400">Verificando integridade dos papéis e permissões institucionais.</p>
               <div className="flex gap-2">
                 <span className="text-[9px] bg-slate-800 px-2 py-1 rounded border border-slate-700">RBAC: ATIVO</span>
                 <span className="text-[9px] bg-slate-800 px-2 py-1 rounded border border-slate-700">PWA: ATIVO</span>
               </div>
            </div>

            {pendingRequests.length === 0 ? (
              <div className="py-20 text-center text-slate-400">
                <p className="text-sm italic">Nenhuma solicitação pendente no momento.</p>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Solicitações Aguardando Aprovação</p>
                {pendingRequests.map(req => (
                  <div key={req.id} className="bg-white border-2 border-slate-100 p-5 rounded-3xl space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-bold text-slate-900">{req.name}</h4>
                        <p className="text-xs text-slate-500">{req.email}</p>
                      </div>
                      <span className="text-[9px] font-bold text-amber-500 uppercase">{req.registrationStatus}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <button onClick={() => handleApprove(req, UserRole.MEMBER)} className="py-3 bg-emerald-600 text-white rounded-xl text-[10px] font-bold uppercase active:scale-95 transition-all">Associado</button>
                      <button onClick={() => handleApprove(req, UserRole.SUPPORT)} className="py-3 bg-slate-800 text-white rounded-xl text-[10px] font-bold uppercase active:scale-95 transition-all">Suporte</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TELA DE ESTATUTO */}
        {tab === 'estatuto' && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold">Estatuto de {institutionName}</h2>
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Doc. Institucional</span>
                <span className="text-[10px] bg-slate-100 px-3 py-1 rounded-full text-slate-600 font-bold">Ref: {association.statuteUpdatedAt}</span>
              </div>
              
              {(isAdmin || user.role === UserRole.FOUNDER) ? (
                <div className="space-y-4">
                  <textarea 
                    className="w-full h-80 p-5 text-sm bg-slate-50 border-2 border-slate-100 rounded-3xl outline-none focus:border-emerald-500 transition-colors resize-none font-medium text-slate-700"
                    value={editingStatute}
                    onChange={(e) => setEditingStatute(e.target.value)}
                  />
                  <button onClick={handleUpdateStatute} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-500/10 active:scale-95 transition-all">Publicar Nova Versão</button>
                </div>
              ) : (
                <div className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap font-medium">
                  {association.statute}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TELA DE FINANÇAS (SOMENTE ADMIN E MEMBER) */}
        {tab === 'pagamento' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Financeiro Institucional</h2>
            
            {isTechnicalStaff ? (
              <div className="p-10 text-center bg-white rounded-[40px] border-2 border-dashed border-slate-200 space-y-4">
                <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-4xl grayscale opacity-30">🔐</div>
                <h3 className="text-lg font-bold text-slate-900">Acesso Restrito</h3>
                <p className="text-xs text-slate-500 leading-relaxed px-4 italic">
                  A equipe de Suporte e Desenvolvimento não possui permissão para visualizar fluxos de caixa, comprovantes ou históricos financeiros por questões de governança e privacidade.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-5">
                   <div className="flex justify-between items-center border-b pb-4">
                     <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Status da Cota</span>
                     <span className="text-sm font-black text-emerald-600 uppercase">{user.status}</span>
                   </div>
                   <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl">
                     <p className="text-[10px] text-emerald-800 font-bold uppercase mb-1">Tesouraria Digital:</p>
                     <p className="text-xs text-emerald-700 leading-relaxed">Em breve ativação de gateway para PIX institucional.</p>
                   </div>
                   <div className="flex justify-between items-center">
                     <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Próxima Contribuição</span>
                     <span className="text-sm font-bold text-slate-900">{user.dueDate || '15/06/2024'}</span>
                   </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TELA DE PERFIL */}
        {tab === 'cadastro' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Perfil Institucional</h2>
            
            {!canSeeSensitiveData ? (
              <div className="bg-slate-100 p-8 rounded-3xl text-center text-slate-400 italic text-xs">
                Dados pessoais de associados protegidos por criptografia e isolamento administrativo.
              </div>
            ) : (
              <div className="bg-white p-6 rounded-[40px] border border-slate-100 space-y-8 shadow-sm relative overflow-hidden">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-20 h-20 bg-emerald-100 text-emerald-700 rounded-3xl flex items-center justify-center text-3xl font-black border-4 border-white shadow-xl">
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-lg">{user.name}</h4>
                    <p className="text-sm text-slate-500">{user.email}</p>
                  </div>
                </div>
                
                <div className="pt-6 border-t border-slate-50 space-y-4">
                  <div className="flex justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    <span>Função</span>
                    <span className="text-slate-900 font-black">{user.role}</span>
                  </div>
                  <div className="flex justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    <span>Instituição</span>
                    <span className="text-slate-900">{institutionName}</span>
                  </div>
                </div>
              </div>
            )}

            <button 
              onClick={() => {setUser(null); setView('LOGIN');}} 
              className="w-full py-4 bg-red-50 text-red-600 rounded-2xl text-xs font-bold border border-red-100 active:scale-95 transition-all"
            >
              Encerrar Sessão com Segurança
            </button>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default App;
